# Slides on Presentations of the MathJax A11Y Extension

## CSUN 2016, San Diego

## Accessing Higher Ground, Denver 2016

* The presentation was jointly with Sam Dooley from Pearson, who presented on
``Generating and Using Accessible Mathematics on the Web`` and demoed their
[Accessible Equation Editor](http://accessibility.pearson.com/aee/).

* Peter Krautzberger's slides are [here](https://pkra.github.io/slides-ahg/).
