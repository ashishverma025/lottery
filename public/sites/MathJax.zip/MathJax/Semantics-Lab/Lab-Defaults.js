//
//  The default options
//
Lab.defaults.enhance = "collapse";
Lab.defaults.overflow = false;
Lab.defaults.highlight = "none";  // "none", "hover", or "flame"
Lab.defaults.width = 100;         // a percentage from 10 to 100
Lab.defaults.background = "blue";
Lab.defaults.foreground = "black";
Lab.defaults.renderer = "HTML-CSS";
Lab.defaults.walker = "syntactic";
